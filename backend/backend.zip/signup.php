<?php
	include 'my.php';
	ini_set('display_errors', false);
	if($_SERVER['REQUEST_METHOD'] === 'POST') {

				$image = post('image');
				//echo $image;
				if($image!='false'){
					//echo 'sent';
					$img = sendimage();
					if($img==false){
						err(403,"File Uploading Failed");
						//exit();
					}

				}
				else {
					$img = '';
				}
				$firstname = post('firstname');
				$lastname = post('lastname');
				$email = post('email');
				$phoneno = post('phoneno');
				$password = md5(post('password'));
				$newarr = [$firstname,$lastname,$email,$phoneno,$password];
				for($i=0;$i<count($newarr);$i++){
					if($newarr[$i]==""||empty($newarr)){
						err(403,"Fill all empty Form Fields");
						exit();
					}
					

				}
				$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyz';
				$jwt = substr(str_shuffle($permitted_chars), 0, 50);
				$jwt2 = substr(str_shuffle($permitted_chars), 0, 50);
				$sql = query("SELECT * FROM users WHERE email='$email' OR usernumber='$phoneno' ");
				$c = check($sql);
				//echo $c;
				if($c>0){
					err(403,"Email Address or Phone Number already registered");
				}
				else {
					$exp = date('h')+1;
					$date = date('i-d/m/yy');
					$r = now();
					$sq = query("INSERT INTO users(firstname,lastname,email,userpassword,usernumber,userimage,useraddress) VALUES('$firstname','$lastname','$email','$password','$phoneno','$img','')");

				if(!$sq){
					err(203,"Request Failed");
				}
				else {
					$sqi = query("SELECT * FROM users WHERE email='$email' AND userpassword='$password' ");
					$rop = fetch($sqi);
					$userid = $rop['userid'];
					$newsql = query("INSERT INTO tokens(token,issuedto,expiry) VALUES('$jwt','$userid','$r')");
					err(200,$jwt."_-_".$r);
				}
				}

	}
	else {
		err(404);
	}
	function sendimage(){
			$extensions = ['jpg', 'jpeg', 'png', 'gif'];
	$name = $_FILES['image']['name'];
	$file_ext = strtolower(end(explode('.',$name)));
	 if (!in_array($file_ext, $extensions)) {
            err(403,"File Not allowed");

            }
            else {
            	if (empty($_FILES['image']['error'])){
            		$file_tmp = $_FILES['image']['tmp_name'];
            	$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyz';
				$newtoken = substr(str_shuffle($permitted_chars), 0, 22);
				$newname = "../images/".$newtoken.".".$file_ext;
				
				if(move_uploaded_file($file_tmp, $newname)){
					

					return $newtoken.".".$file_ext;
				}
				else {
					return false;
				}
            }
	//print($data);
        }
	}
	function err($e,$err){
		$result = new stdClass;
		
		$result->code = $e;
		$result->token = $err;
		print(json_encode($result));	
		exit();
	}
?>