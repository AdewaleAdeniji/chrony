
<?php
$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "" ;
$dbName ="echeckers";
$conn = mysqli_connect($dbServername, $dbUsername,$dbPassword,$dbName);
/*
if(!$conn) {
echo "Error";
} 
else {
echo "successful";
} */
?>