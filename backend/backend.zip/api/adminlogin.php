<?php
	include 'parse.php';
	$dat = '{"adminmail":"a@a.a","password":"admin"}';
	$data = json_decode(file_get_contents('php://input'));
	//$data = json_decode($dat);
	if(empty($data)){
		say(203,"Empty Request Body");
	}
	else {
		if(empty($data->adminmail)||empty($data->password)){
			say(203,"Empty Form Field");
		}
		else {
			$adminmail= parse($data->adminmail);
			$adminpassword = parse($data->password);
			$log = query("SELECT * FROM admins WHERE adminemail='$adminmail' AND adminpassword='$adminpassword' ");
			if(check($log)<1){
				say(203,"Incorrect Email or Password");
			}
			else {
			$row = fetch($log);
			$status = $row['status'];
			if($status=='0'){
				say(203,"Incorrect Email or Password");
				exit();
			}
			$userid = 1;
			$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyz';
			$jwt = substr(str_shuffle($permitted_chars), 0, 50);
			$exp = date('h')+1;
			$date = date('i-d/m/yy');
			$r = now();
			$savetoken = query("INSERT INTO tokens(token,issuedto,expiry) VALUES('$jwt','$userid','$r')");
			if(!$savetoken){
				say(203,"Signin Failed");
			}
			else {
				say(200,$jwt."_-_".$r);
			}
			}
		}
	}
?>