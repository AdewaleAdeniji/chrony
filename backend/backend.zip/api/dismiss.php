<?php
	include 'parse.php';
	if(auth()){
	$userid = auth();
	$dat = '{"token":"test","uid":"91828"}';
	$data = json_decode(file_get_contents('php://input'));
	//$data = json_decode($dat);
	if (empty($data)) {
		say(203,"Invalid Request");
		# code...
	}
	else {
		if(empty(i($data,'uid'))){
			say(203,"UID number missing");
		}
		else {
			$uid = i($data,'uid');
			$sql = query("SELECT * FROM hardwares WHERE iudnumber='$uid' ");
			$count = check($sql);
			if($count<1){
				say(203,"IUD number not found");
			}
			else {
				$row = fetch($sql);
				$ownerid = $row['userid'];
				$active = $row['active'];
				 if($active=='DEACTIVATED'){
			            say(203,"Device have already been deactivated");
			            exit();
			        }
				if($ownerid==$userid||$userid=="1"){
					$nsql = query("UPDATE hardwares SET active='DEACTIVATED' WHERE iudnumber='$uid' ");
					if(!$nsql){
						say(203,"Request Failed: REF CODE: DISMISS29");
					}
					else {
						say(200,$uid." have been successfully deactivated");
					}
				}
				else {
					say(203,"You are not allowed to make changes to this hardware");
				}
			}
		}
	}
}
?>