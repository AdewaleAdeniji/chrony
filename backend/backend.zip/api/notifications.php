<?php
	include 'parse.php';
	if(auth()){
		$userid = auth();
		$sql = query("SELECT * FROM notifications WHERE showto='$userid' OR showto='*' ORDER BY id DESC");
		$not = [];
		while ($row=fetch($sql)) {
			# code...
			$msg = new stdclass();
			$msg->time = $row['timest'];
			$msg->notification = $row['notification'];
			$msg->type = $row['type'];
			array_push($not,$msg);
		}
		say(200,$not);
	}
?>