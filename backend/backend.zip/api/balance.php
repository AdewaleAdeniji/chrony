<?php
	include 'parse.php';
	if(auth()){
		$userid = auth();
		$sql = query("SELECT * FROM users WHERE userid='$userid' ");
		$row = fetch($sql);
		$balance = $row['balance'];
		$msg= new stdclass();
		$msg->balance = $balance;
		say(200,$msg);
	}

?>