<?php
 include 'parse.php';
 if(auth()){
 	$userid = auth();
 	$sql = query("SELECT * FROM users WHERE userid='$userid' ");
 	if(check($sql)<1){
 		say(205,"Please login again");
 	}
 	else {
 		$row = fetch($sql);
 		$firstname = $row['firstname'];
 		$lastname = $row['lastname'];
 		$email = $row['email'];
 		$address = $row['useraddress'];
 		$image = $row['userimage'];
 		$msg = new stdclass();
 		$msg->firstname = $firstname;
 		$msg->lastname = $lastname;
 		$msg->email = $email;
 		$msg->address = $address;
 		$msg->imageurl = $image;
 		$msg->number = $row['usernumber'];
 		say(200,$msg);
 	}
 }

?>