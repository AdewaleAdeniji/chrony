<?php

	include 'parse.php';
	$dat = '{"adminmail":"a@a.a","adminpassword":"admin"}';
	$data = json_decode(file_get_contents('php://input'));
	//$data = json_decode($dat);
	if(auth()){
		$userid = auth();
		$sql = query("SELECT * FROM users WHERE userid='$userid' ");
		$ty = fetch($sql);
		if($ty['lastname']=='admin'){
			$adminmail = parse($data->adminmail);
			$adminpassword = parse($data->adminpassword);
				$val = query("SELECT * FROM admins WHERE adminemail='$adminmail' AND adminpassword='$adminpassword' ");
				if(check($val)<1){
					say(203,"Incorrect Email or Password");
				}
				else {
					$e = fetch($val);
					if($e['id']==1){
						$admins = query("SELECT * FROM admins ORDER BY id DESC");
						$m = [];
						while ($admin=fetch($admins)) {
							# code...
							if($admin['id']!='1'){
							$msg = new stdclass();
							$msg->adminame = $admin['adminame'];
							$msg->adminmail = $admin['adminemail'];
							$msg->status = $admin['status'];
							$msg->adminid = $admin['id'];
							array_push($m, $msg);
						}
						}
						say(200,$m);
					}
					else {
						say(203,"You are not allowed to visit this page");
					}
				}
		}
		else {
			say(403,"Forbidden Request");
		}
	}

?>