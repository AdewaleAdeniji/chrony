<?php
	include 'parse.php';
	if(auth()){
		$userid = auth();
		$sql = query("SELECT * FROM users WHERE userid='$userid'  AND lastname='admin' ");
		if(check($sql)<1){
			say(205,"Unauthorized Access");
		}
		else {
			$nsql = query("SELECT * FROM trx ORDER BY timest DESC");
			//$row = fetch($nsql);
			$arr = [];
			while ($row=fetch($nsql)) {
				$trx = new stdclass();
				$trx->desc = $row['textdesc'];
				$trx->datetime = $row['timest'];
				$trx->referenceid = $row['referenceid'];
				array_push($arr,$trx);
			}
			say(200,$arr);
		}
	}
?>