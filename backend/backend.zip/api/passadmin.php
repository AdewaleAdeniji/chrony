<?php
	include 'parse.php';
	 $dat = '{"adminmail":"adminmail","password":"password","newpassword":"admins"}';
	$data = json_decode(file_get_contents('php://input'));
	//$data = json_decode($dat);
	 if(auth()){
	 	$userid = auth();
	 	if(empty($data->password)||empty($data->newpassword)){
	 		say(203,"Empty Form Fields");
	 	}
	 	else {
	 		$password = parse($data->password);
	 		$newpassword =parse($data->newpassword);
	 		$adminmail = parse($data->adminmail);
	 		$sql =query("SELECT * FROM admins WHERE adminemail='$adminmail' AND adminpassword='$password' ");
	 		if(check($sql)<1){
	 			say(203,"Incorrect Password");
	 		}
	 		else {
	 			$update = query("UPDATE admins SET adminpassword='$newpassword' WHERE adminemail='$adminmail' ");
	 			if(!$update){
	 				say(203,'Request Failed');
	 			}
	 			else {
	 			say(200,"Password Updated successfully");
	 		}
	 		}
	 	}
	 }
?>