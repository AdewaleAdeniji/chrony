<?php
	include 'parse.php';
	if(auth()){
		$userid = auth();
		$sql = query("SELECT * FROM users WHERE userid='$userid' ");
		if(check($sql)<1){
			say(205,"Login again");
		}
		else {
			$user = fetch($sql);
			if($user['lastname']=='admin'){
				//admin authenticated
				$sql = query("SELECT * FROM users ORDER BY userid DESC");
				$users = [];
				while ($row=fetch($sql)) {
					# code...
					$msg = new stdclass();
					if($row['lastname']!="admin"){
					$msg->firstname = $row['firstname'];
					$msg->lastname = $row['lastname'];
					$msg->balance = $row['balance'];
					$msg->email = $row['email'];
					$msg->number = $row['usernumber'];
					array_push($users, $msg);
					}
				}
				say(200,$users);
			}	
			else {
				say(403,"Access denied to this page");
			}
		}
	}
?>