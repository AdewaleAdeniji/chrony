<?php
	include 'parse.php';
	if(auth()){
		$userid = auth();
		$sql = query("SELECT * FROM users WHERE userid='$userid'  AND lastname='admin' ");
		if(check($sql)<1){
			say(205,"Unauthorized Access");
		}
		else {
			$nsql = query("SELECT * FROM hardwares ORDER BY activatedate DESC");
			//$row = fetch($nsql);
			$arr = [];
			while ($row=fetch($nsql)) {
				$uid = $row['iudnumber'];
				$amount = $row['amount'];
				$active = $row['active'];
				$location = $row['location'];
				$activatedate = $row['activatedate'];
				$hardwares = new stdclass();
				$hardwares->uidnumber = $uid;
				$hardwares->amount = number_format($amount);
				$hardwares->active = $active;
				$hardwares->location = $location;
				$hardwares->activatedate = $activatedate;
				array_push($arr,$hardwares);
			}
			say(200,$arr);
		}
	}
?>