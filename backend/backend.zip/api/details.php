<?php
 include 'parse.php';
 if(auth()){
 $dat = '{"token":"test","uid":"91828"}';
 $data = json_decode(file_get_contents('php://input'));
  //$data = json_decode($dat);
  if(empty($data->uid)){
  		say(203,"IUD number missing");
  }
  else {
  	$userid = auth();
  	$uid = parse($data->uid);
  	$sql = query("SELECT * FROM hardwares WHERE iudnumber='$uid' ");
		if(check($sql)<1){
			say(203,"Hardware not found");
		}
		else {
			$row = fetch($sql);
			$ownerid = $row['userid'];

			if($userid==$ownerid||$userid==1){
				$msg = new stdclass();
				$ownerq = query("SELECT * FROM users WHERE userid='$ownerid' ");
				$q = fetch($ownerq);
				$firstname = $q['firstname'];
				$lastname = $q['lastname'];
				$email = $q['email'];
				$address = $q['useraddress'];
				$date = $row['activatedate'];
				$amount = $row['amount'];
				$msg->firstname = $firstname;
				$msg->lastname = $lastname;
				$msg->email = $email;
				$msg->address = $address;
				$msg->activate_date = $date;
				$msg->amount = $amount;
				say(200,$msg);
			}
			else {
				say(203,"Access Denied to this resource");
			}
		}
  }
 }
?>