<?php
  
  include 'parse.php';
  $dat = '{"uid":"239893"}';
   $data = json_decode(file_get_contents('php://input'));
  //$data = json_decode($dat);
  if(empty($data)){
  	say(203,'Invalid Request Body');
  }
  else {
  	if(empty($data->uid)){
  		say(203,"Invalid Request Body");
  	}
  	else {
  		$uid = parse($data->uid);
  		$c = query("SELECT * FROM hardwares WHERE iudnumber='$uid' ");
  		if(check($c)>0){
  			say(203,'Device with ID'.$uid.' have already been added');
  			exit();
  		}
  		$sql = query("INSERT INTO hardwares(iudnumber,userid,active,amount,location,activatedate) VALUES('$uid','0','0','0','0','0') ");
  		if(!$sql){
  			say(203,"Request Failed");
  		}
  		else {
  			say(200,"Device with ID ".$uid." have been Successfully added");
  		}
  	}
  }

?> 