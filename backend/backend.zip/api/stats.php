<?php
 include 'parse.php';
 if(auth()){
 $dat = '{"token":"test","uid":"91828"}';
  $data = json_decode(file_get_contents('php://input'));
 // $data = json_decode($dat);
  if(empty($data->uid)){
  		say(203,"IUD number missing");
  }
  else {
  	$userid = auth();
  	$uid = parse($data->uid);
  	$sql = query("SELECT * FROM hardwares WHERE iudnumber='$uid' ");
		if(check($sql)<1){
			say(203,"Hardware not found");
		}
		else {
			$row = fetch($sql);
			$ownerid = $row['userid'];

			if($userid==$ownerid||$userid==1){
				$nsql = query("SELECT * FROM measures WHERE iudnumber='$uid' ");
				if(check($nsql)<1){
					$arr = [];
					$msg = new stdclass();
					$msg->voltage =0;
					$msg->current = 0;
					$msg->power = 0;
					$msg->time = now();
					array_push($arr,$msg);
					say(200,$arr);
				}
				else {
					$arr = [];
					while($measures = fetch($nsql)){
						$msg = new stdclass();
						$msg->voltage = $measures['voltage'];
						$msg->current = $measures['current'];
						$msg->power = $measures['power'];
						$msg->time = $measures['timest'];
						array_push($arr,$msg);
					}
					say(200,$arr);
				}
			}
			else {
				say(205,"Access Denied to this resource");
			}
		}
  }
 }
?>