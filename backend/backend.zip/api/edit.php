<?php
	include 'parse.php';
	$dat = '{"token":"test","firstname":"adewale","lastname":"admin","password":"password","address":"address"}';
	 $data = json_decode(file_get_contents('php://input'));
 	//$data = json_decode($dat);
	if(auth()){
		$userid = auth();
		if(empty($data->firstname)||empty($data->lastname)||empty($data->password)){
			say(203,"Empty Form Fields");
		}
		else {
			
			$firstname = parse($data->firstname);
			$lastname = parse($data->lastname);
			$password = parse($data->password);
			$address = parse($data->address);
			$pass = query("SELECT * FROM users WHERE userid='$userid'  AND userpassword='$password' ");
			if(check($pass)<1){
				say(203,"Incorrect Password");
				exit();
			}
			else {
			$updatesql = query("UPDATE users SET firstname='$firstname',lastname='$lastname',useraddress='$address' WHERE userid='$userid' AND userpassword='$password' ");
			if(!$updatesql){
				say(203,"Profile Update Failed");
			}
			else {
				say(200,"Profile Update Successful");
			}
			}
		}
	}
?>