<?php
	include 'parse.php';

	 $dat = '{"token":"test","uid":"91828","voltage":"240","current":"13","power":"3200"}';
	  $data = json_decode(file_get_contents('php://input'));
	  //$data = json_decode($dat);
	  if(empty($data->uid)){
	  		 say(203,"UID number not present");
	  }
	  else {
	  	  $uid = parse($data->uid);
	  	  if(checksub($uid)){
	  	  	 	if(empty($data->voltage)||empty($data->current)||empty($data->power)){
	  	  	 		say(203,"voltage or Current parameters are missing");
	  	  	 	}
	  	  	 	else {
	  	  	 		$voltage = parse($data->voltage);
	  	  	 		$current = i($data,'current');
	  	  	 		$power = i($data,'power');
	  	  	 		$date = now();
	  	  	 		$t = $power/75;
	  	  	 		$amount = checksub($uid);
	  	  	 		if($t>$amount){
            			 $o = query("SELECT userid FROM hardwares WHERE iudnumber='$uid' ");
            			 $op = fetch($o);
            			 $userid = $op['userid'];
            			 notify("Insuffient Funds to process informations on ".$uid,"1",$userid);
	  	  	 			 say(203,"Insuffient Funds to continue saving data");
            			 exit();
	  	  	 		}
	  	  	 		$newamount = $amount-$t;
			        update($uid,$newamount);
	  	  	 		$sql = query("INSERT INTO measures(iudnumber,voltage,current,power,timest) VALUES('$uid','$voltage','$current','$power','$date') ");
	  	  	 		if(!$sql){
	  	  	 			say(203,"Request Failed : RF CODE: MEASURE INSERT POINT 568");
	  	  	 		}
	  	  	 		else {
	  	  	 			say(200,'success');
	  	  	 		}

	  	  	 	}
	  	  }
	  }
	
?>