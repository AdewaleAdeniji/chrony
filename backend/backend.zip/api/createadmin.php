<?php
	include 'parse.php';
	$dat = '{"adminmail":"a@a.e","password":"admin","adminame":"feranmi"}';
	$data = json_decode(file_get_contents('php://input'));
	//$data = json_decode($dat);
	if(auth()){
		$userid = auth();
		$sql = query("SELECT * FROM users WHERE userid='$userid' ");
		if(check($sql)<1){
			say(205,"Login again");
		}
		else {
			$user = fetch($sql);
			if($user['lastname']=='admin'){
				if(empty($data->adminmail)||empty($data->password)||empty($data->adminame)){
					say(203,"Empty Form Fields");
				}
				else {
					$adminame = parse($data->adminame);
					$adminmail = parse($data->adminmail);
					$adminpassword = parse($data->password);
					$ch = query("SELECT * FROM admins WHERE adminemail='$adminmail' ");
					if(check($ch)>0){
						say(203,"Admin Email already exists");
						exit();
					}
					$save = query("INSERT INTO admins(adminame,adminpassword,adminemail,status,adminid) VALUES('$adminame','$adminpassword','$adminmail','1','1')");
					if(!$save){
						say(203,"Admin creation failed");
					}
					else {
						say(200,"Admin created successfully");
					}
				}
			}	
			else {
				say(403,"Access denied to this page");
			}
		}
	}
?>