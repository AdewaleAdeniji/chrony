<?php
  include 'parse.php';
  $dat = '{"token":"test","uid":"91828","location":"Ibadan"}';
  $data = json_decode(file_get_contents('php://input'));
  //$data = json_decode($dat);
  //echo now();
  if(auth()){
  		$userid = auth();
  		if(empty($data)){
  			say(203,'invalid request');
  			exit();
  		}
  		else {
  			if(empty($data->uid)){
  				say(203,'invalid request body: UID is missing');
  				exit();
  			}
  			else {
  				$checkvalid = checkvalid(parse($data->uid));
  				if($checkvalid){
  					if(parse($data->location)!==null) {
  						$location = $data->location;
  					}
  					else {
  						$location = 'NILL';
  					}
  					$id = $checkvalid;
  					$date = now();
  					$uid = parse($data->uid);
  					$active = 'Active';
  					$ins = query("UPDATE hardwares SET userid='$userid',active='$active',activatedate = '$date' ,location='$location' WHERE id='$id' ");
  					if(!$ins){
  						say(203,"Activation Failed");
  					}
  					else {
  						say(200,'Activation Success');
  					}
  				}
  			}
  		}
	}
   function checkvalid($uid){
   		$sql = query("SELECT * FROM hardwares WHERE iudnumber='$uid'");
   		if(check($sql)<1){
   			say(400,"Invalid IUD number");
   		}
   		else {
   			$row = fetch($sql);
   			$active = $row['active'];
   			if($active=='0'){
   				return $row['id'];
   			}
   			else if($active=="DEACTIVATED"){
   				return $row['id'];
   			}
   			else {
   				say(203,"IUD have already been registered");
   			}
   		}
   }
  	
?>