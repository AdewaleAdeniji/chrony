<?php

	include 'parse.php';
	$dat = '{"adminid":"2","status":"0"}';
	$data = json_decode(file_get_contents('php://input'));
	//$data = json_decode($dat);
	if(auth()){
		$userid = auth();
		$sql = query("SELECT * FROM users WHERE userid='$userid' ");
		$ty = fetch($sql);
		if($ty['lastname']=='admin'){
			$id = parse($data->adminid);
			//$adminpassword = parse($data->adminpassword);
				$val = query("SELECT * FROM admins WHERE id='$id' ");
				if(check($val)<1){
					say(203,"Admin not available");
				}
				else {
					$e = fetch($val);
					$id = $e['id'];
					$status = parse($data->status);
					if(empty($status)&&$status!='0'){
						say(203,"Status not present".$status);
						exit();
					}
					$up = query("UPDATE admins SET status='$status' WHERE id='$id' ");
					if(!$up){
						say(203,"Request Failed");
					}
					else {
						say(200,"Admin Updated Successfully".$status);
					}
				}
		}
		else {
			say(403,"Forbidden Request");
		}
	}

?>