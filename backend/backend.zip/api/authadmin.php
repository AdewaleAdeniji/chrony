<?php
	include 'parse.php';
	$data = parser();
	echo 'yooooo';
?>