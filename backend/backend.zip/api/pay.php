<?php
 include 'parse.php';
 $dat = '{"paymentref":"3484894","amount":"50000","datetime":"23:12-12/07/2020"}';
	//$data = json_decode(file_get_contents('php://input'));
	$data = json_decode($dat);
 if(auth()){
 	$userid = auth();
 	if(empty($data->paymentref)||empty($data->amount)||empty($data->datetime)){
 		say(203,"Empty Request Body");
 	}
 	$paymentref = parse($data->paymentref);
 	$amount = parse($data->amount);
 	$datetime = parse($data->datetime);

 	$price = verify($paymentref,$amount);
 	$updatebal = query("SELECT * FROM users WHERE userid ='$userid' ");
    		if(check($updatebal)<1){
    			say(205,"Invalid User,Plese Login again");
    		}
    		else {
    			$user = fetch($updatebal);
    			$balance = $user['balance'];
    			$newbalance = $balance+$price;
    			$newbal = query("UPDATE users SET balance='$newbalance' WHERE userid='$userid' ");
    			$text = "Your payment of ".$amount." is successful with referenceid :".$paymentref;
    			paylog($text,$userid,'1',$paymentref,$price);
 				notify("Your payment of ".$amount." is successful with referenceid :".$paymentref,'1',$userid);
 				say(200,"Payment of ".$price." successful");
    		}
 		
 }
	function paylog($text,$userid,$status,$ref,$amount){
		$date = now();
	$rtt = "INSERT INTO payments(statustext,amount,referenceid,status,userid,timest) VALUES('$text','$amount','$ref','$status','$userid','$date')";
	$psql = query($rtt);
	

	}
function verify($ref,$amount){
	return $amount;
}
?>