<?php
	include 'parse.php';
	 $dat = '{"password":"password","newpassword":"admins"}';
	$data = json_decode(file_get_contents('php://input'));
	//$data = json_decode($dat);
	 if(auth()){
	 	$userid = auth();
	 	if(empty($data->password)||empty($data->newpassword)){
	 		say(203,"Empty Form Fields");
	 	}
	 	else {
	 		$password = md5(parse($data->password));
	 		$newpassword = md5(parse($data->newpassword));
	 		$sql =query("SELECT * FROM users WHERE userid='$userid' AND userpassword='$password' ");
	 		if(check($sql)<1){
	 			say(203,"Incorrect Password");
	 		}
	 		else {
	 			$update = query("UPDATE users SET userpassword='$newpassword' WHERE userid='$userid' ");
	 			say(200,"Password Updated successfully");
	 		}
	 	}
	 }
?>