<?php
	include 'parse.php';
	if(auth()){
		$dat = '{"token":"test","uid":"91828","package":"3"}';
		 // $data = json_decode(file_get_contents('php://input'));
 		 $data = json_decode($dat);
		 $userid = auth();
		 $sql = query("SELECT * FROM users WHERE userid='$userid' ");
		 $row = fetch($sql);
		 $balance = $row['balance'];
		 if(empty($data->uid)||empty($data->package)){
		 	say(203,"UID or Package number missing");
		 	exit();
		 }
		 else {
		 	$uid = parse($data->uid);
		 	$package = parse($data->package);
		 	$p = query("SELECT * FROM packages WHERE id='$package' ");
		 	if(check($p)<1){
		 		say(203,"Package Number not found or missing");
		 		exit();
		 	}
		 	$rop = fetch($p);
		 	$price = $rop['packageprice'];
		 	if($balance<$price){
		 		say(203,"Insufficient Fund to process this transaction");
		 		exit();
		 	}
		 	else {
		 		$newbalance = $balance-$price;
		 		$rebal = query("UPDATE users SET balance='$newbalance' WHERE userid='$userid' ");
		 		$r = query("SELECT * FROM hardwares WHERE iudnumber='$uid' ");
		 		$tio = fetch($r);
		 		$amount = $tio['amount']+$price;
		 		update($uid,$amount);
		 		$ref = gen();
		 		$date = now();
		 		$text = $uid." has been successfully recharged with ".$price ." New balance is ".number_format($amount)." Reference ID:".$ref;
		 		$trx = query("INSERT INTO trx(timest,textdesc,referenceid,userid) VALUES('$date','$text','$ref','$userid') ");
		 		say(200,$text);
		 		notify($text,"0",$userid);
		 	}
		 }

	}

?>