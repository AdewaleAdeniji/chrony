<?php
	 
	 include 'parse.php';
	 if(auth()){
	 	$userid = auth();
	 	$sql = query("SELECT * FROM hardwares WHERE userid='$userid' ");
	 	if(check($sql)<1){
	 		say(201,"You dont have any activated device");
	 	}
	 	else {
	 		$hardwares = [];
	 		while ($row=fetch($sql)) {
	 			# code...
	 			$msg = new stdclass();
	 			$msg->uid = $row['iudnumber'];
	 			$msg->location = $row['location'];
	 			$msg->activatedate = $row['activatedate'];
	 			$msg->active = $row['active'];
	 			$msg->amount = number_format($row['amount']);
	 			array_push($hardwares,$msg);
	 		}
	 		say(200,$hardwares);

	 	}
	 }


?>