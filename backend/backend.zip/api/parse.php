<?php
	include '../my.php';
	function auth(){
	 try {
	 $msg = new stdclass();
	 $dat = '{"token":"test"}';
	 $data = json_decode(file_get_contents('php://input'));
	 //$data = json_decode($dat);

	 if(empty($data)){
	 	say(203,'Invalid Request');
	 	exit();
	 }
	 else if (empty($data->token)){
	 	say(203,'Empty Request Body');
	 	exit();
	 }

	 $authtoken = parse($data->token);
	 if(isset($authtoken)){
	 	//return $data;
	 	$sql = query("SELECT * FROM tokens WHERE token='$authtoken' ");
	 	$check = check($sql);
	 	if($check<1){
	 		say(205,"Invalid Authentication Token");
	 	}
	 	else {
	 		//echo $check;
	 		$row = fetch($sql);
	 		$userid = $row['issuedto'];
	 		$finduser = query("SELECT * FROM users WHERE userid='$userid' ");
	 		if(check($finduser)<1){
	 			say(205,'You need to login to authenticate nouser');
	 		}
	 		//tokens expires in 2 hours so hour-hour
	 		//02:53-07/09/2020
	 		 $hournow = date('H');
	 		 $daynow = date('d')*1;
	 		 $date = $row['expiry'];
	 		 $hou = explode(':',$date);
	 		 $arr = explode('-', $date);
	 		 $sec = explode('/',$arr[1]);
	 		 $day = $sec[0];
	 		 if($day!=$daynow){
	 		 	say(205,'You need to login to authenticate day');
	 		 	exit();
	 		 }
	 		 $hour = $hou[0]*1;
	 		 $diff = abs($hournow-$hour);
	 		 if($diff>2){
	 		 	say(205,'You need to login to authenticate hour');
	 		 	exit();
	 		 }
	 		 else {
	 		 	return $userid;
	 		 }

	 	}
	 }
	 else {
	 	say(203,'Invalid Authentication token');
	 }
	  }
	 catch(Exception $err){
	 	//log  $er->getmessage();
	 	say(404,'');
	 }
	 }

	
?>