<?php
	include 'my.php';
	say(200,"Your API hit successfully");
?>